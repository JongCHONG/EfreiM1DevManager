import React, { useContext } from "react";
import MessageSender from "../MessageSender/MessageSender";
import MessageReceiver from "../MessageReceiver/MessageReceiver";
import { UsernameContext } from "../../contexts/UsernameContext";
import { UsersContext } from "../../contexts/UsersContext";
import "animate.css";

const ChatRoom = () => {
  const { username } = useContext(UsernameContext);
  const { users } = useContext(UsersContext);
  let time = 1;

  return (
    <>
      <div className="d-flex" style={{ height: "100%", width: "100%" }}>
        <div style={{ width: "20%", padding: "2%" }}>
          {users.map((user, index) => {
            time++;
            return (
              <div className={"animate__animated animate__fadeInLeft animate__delay-0." + time + "s"}>
                <div
                  key={index}
                  className="bg-info-subtle px-3 fs-5 mb-1 rounded-pill d-flex justify-content-center align-items-center"
                  style={{ height: "6%", width: "100%" }}
                >
                  {user}
                </div>
              </div>
            );
          })}
        </div>
        <div className="border-start" style={{ width: "80%" }}>
          <h2 className="px-4 pt-3">Welcome to the jungle, {username}!</h2>

          <div className="px-4 overflow-y-auto" style={{ height: "70%" }}>
            <MessageReceiver />
          </div>

          <div className="border-top px-4 pt-4" style={{ height: "30%" }}>
            <MessageSender />
          </div>
        </div>
      </div>
    </>
  );
};

export default ChatRoom;
