import React, { useContext } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { UsernameContext } from "../../contexts/UsernameContext";
import logo from "../../assets/logo.jpeg";
import Form from "react-bootstrap/Form";
import InputGroup from "react-bootstrap/InputGroup";

import Card from "react-bootstrap/Card";
const Username = () => {
  const { username, setUsername } = useContext(UsernameContext);
  const navigate = useNavigate();

  const createQueue = async () => {
    try {
      await axios.post("http://localhost:5000/create-queue", {
        queue: username,
      });
      console.log("Queue created successfully!");
      navigate("/chatroom");
    } catch (error) {
      console.error("Error creating queue:", error);
      console.log("Error creating queue. See console for details.");
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      createQueue();
    }
  };

  return (
    <>
        <Card style={{ width: "20rem", boxShadow: "5px 5px 15px 5px #7E7E7E" }}>
          <Card.Img variant="top" src={logo} className="mt-4" />
          <Card.Body className="text-center">
            <Card.Title>Welcome to The Rabbits Den</Card.Title>
            <Card.Text >
              Are you ready to join the fight?
            </Card.Text>
            <InputGroup className="mb-3">
              <Form.Control
                placeholder="Username"
                aria-label="Username"
                aria-describedby="basic-addon1"
                value={username} 
                onKeyPress={handleKeyPress}
                onChange={(e) => setUsername(e.target.value)} 
              />
              <button onClick={createQueue}>Join the fight!</button>
            </InputGroup>
          </Card.Body>
        </Card>
        {/* <input
        type="text"
        value={username}
        onChange={(e) => setUsername(e.target.value)}
        placeholder="Enter queue name"
      /> */}
    </>
  );
};

export default Username;
