import React, { useContext, useState } from "react";
import axios from "axios";
import { UsernameContext } from "../../contexts/UsernameContext";
import { Button, FloatingLabel, Form } from "react-bootstrap";

const MessageSender = () => {
  const [message, setMessage] = useState("");
  const [remainingChars, setRemainingChars] = useState(200);

  const { username } = useContext(UsernameContext);

  const sendMessage = async () => {
    try {
      await axios.post("http://localhost:5000/send", { message, username });
      console.log("Message sent successfully!");
    } catch (error) {
      console.error("Error sending message:", error);
      console.log("Error sending message. See console for details.");
    }
  };

  const handleTextChange = (e) => {
    setMessage(e.target.value);
    setRemainingChars(200 - e.target.value.length);
  };
  
  const handleKeyPress = (e) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  return (
    <>
      <FloatingLabel
        controlId="floatingTextarea2"
        label="Write your punchline !"
      >
        <Form.Control
          as="textarea"
          value={message}
          onKeyPress={handleKeyPress}
          onChange={handleTextChange}
          placeholder="Type your message here"
          style={{ height: "100px" }}
          maxLength={200}
        />
        <div className="mt-2">{remainingChars} caractères restants</div>
      </FloatingLabel>
      <Button className="mt-2" variant="primary" onClick={sendMessage}>
        Envoyer
      </Button>
    </>
  );
};

export default MessageSender;
