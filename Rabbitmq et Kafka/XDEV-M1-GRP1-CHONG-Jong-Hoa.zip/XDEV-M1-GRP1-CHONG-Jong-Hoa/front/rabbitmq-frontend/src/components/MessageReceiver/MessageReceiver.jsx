import React, {
  useState,
  useEffect,
  useRef,
  useContext,
  useCallback,
} from "react";
import axios from "axios";
import { UsernameContext } from "../../contexts/UsernameContext";
import moment from "moment";
import "moment/locale/fr";
import { UsersContext } from "../../contexts/UsersContext";

const MessageReceiver = () => {
  const [messages, setMessages] = useState([]);
  const { username } = useContext(UsernameContext);
  const { setUsers } = useContext(UsersContext);
  const socket = useRef(null);

  useEffect(() => {
    socket.current = new WebSocket("ws://localhost:8080");

    socket.current.onopen = () => {
      console.log("WebSocket connection established");
      socket.current.send(JSON.stringify({ username }));
    };
    
    socket.current.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'userList') {
          setUsers(data.users);
        } else {
          setMessages((messages) => [...messages, data]);
    
          setUsers((users) => {
            if (!users.includes(data.username)) {
              return [...users, data.username];
            } else {
              return users;
            }
          });
        }
      } catch (error) {
        console.error("Received data is not in JSON format:", event.data);
      }
    };

    return () => {
      socket.current.close();
    };
  }, [username, setUsers]);

  const receiveMessage = useCallback(async () => {
    try {
      axios
        .get(`http://localhost:5000/messages/${username}`)
        .then((response) => {
          setMessages(response.data);
        })
        .catch((error) => {
          console.error("Error fetching messages:", error);
        });
    } catch (error) {
      console.error("Error receiving message:", error);
      console.log("Error receiving message. See console for details.");
    }
  }, [username]);

  useEffect(() => {
    receiveMessage();
  }, [receiveMessage]);

  return (
    <div>
      {messages?.map((message, index) => (
        <div
          key={index}
          className={`d-flex ${
            message.username === username
              ? "justify-content-start"
              : "justify-content-end"
          }`}
        >
          <div
            style={{
              width: "50%",
            }}
          >
            <div>{message.username}</div>
            <div
              className="bg-info bg-gradient bg-opacity-25 py-3 px-4 rounded-pill"
              style={{
                wordWrap: "break-word",
              }}
            >
              {message.message}
            </div>
            <p className="text-end fw-lighter fst-italic">
              Envoyé le {moment(message.createdAt).locale("fr").format("LLLL")}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MessageReceiver;
