import React, { createContext, useState } from 'react'

const UsernameContext = createContext({})

const UsernameContextProvider = props => {
  const [username, setUsername] = useState('')

  const value = {
    username,
    setUsername
  }

  return (
    <UsernameContext.Provider value={value}>
        {props.children}
    </UsernameContext.Provider>
  )
}

export {
  UsernameContextProvider,
  UsernameContext
}