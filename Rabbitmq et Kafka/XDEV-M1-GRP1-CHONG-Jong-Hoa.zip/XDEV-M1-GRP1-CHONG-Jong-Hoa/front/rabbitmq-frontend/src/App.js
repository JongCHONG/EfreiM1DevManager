import React, { useContext, useEffect } from "react";
import { Routes, Route, useLocation, useNavigate } from "react-router-dom";
import "./App.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import Home from "./pages/Home/Home";
import ChatRoom from "./components/ChatRoom/ChatRoom";
import { UsernameContext } from "./contexts/UsernameContext";

function App() {
  const location = useLocation();
  const navigate = useNavigate();
  const { username } = useContext(UsernameContext);

  useEffect(() => {
    if (!username) {
      navigate("/");
    }
  }, [username, navigate]);

  return (
    <>
      <div className="background">
        <Routes location={location} key={location.pathname}>
          <Route exact path="/" element={<Home />} />
          <Route path="/chatroom" element={<ChatRoom />} />
        </Routes>
      </div>
    </>
  );
}

export default App;
