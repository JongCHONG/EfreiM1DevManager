import React from "react";
import Username from "../../components/Username/Username";

const Home = () => {
  return (
    <div
      className="d-flex justify-content-center align-items-center"
      style={{ height: "100%" }}
    >
      <Username />
    </div>
  );
};

export default Home;
